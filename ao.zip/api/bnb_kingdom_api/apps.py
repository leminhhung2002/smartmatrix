from django.apps import AppConfig


class BnbKingdomApiConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'bnb_kingdom_api'
